## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)
library(datalab)

## -----------------------------------------------------------------------------
# Load the sample agriculture dataset
data(agriculture_data)
data <- agriculture_data

## -----------------------------------------------------------------------------
head(data)

## -----------------------------------------------------------------------------
linechart(nitrogen_content, crop_yield)

## -----------------------------------------------------------------------------
# Load heart disease data
data(heart_data)
data <- heart_data

boxplot(age)

## -----------------------------------------------------------------------------
boxplot(age, group = 'sex')

## -----------------------------------------------------------------------------
piechart(chest_pain_type)

## -----------------------------------------------------------------------------
piechart(chest_pain_type, 'sex')

## -----------------------------------------------------------------------------
descriptives(age, resting_bp, cholesterol)

## -----------------------------------------------------------------------------
frequencies(chest_pain_type)

## ----eval=FALSE---------------------------------------------------------------
# x = nitrogen_content
# y = crop_yield
# linechart(x, y)

## ----eval=FALSE---------------------------------------------------------------
# a = chest_pain_type
# b = age
# piechart(a, b)

## ----eval=FALSE---------------------------------------------------------------
# # For CSV files
# data <- read.csv("myfile.csv")
# 
# # For Excel files (requires readxl package)
# library(readxl)
# data <- read_excel("myfile.xlsx")

## ----eval=FALSE---------------------------------------------------------------
# data <- my_dataset

## -----------------------------------------------------------------------------
frequencies(chest_pain_type)

## ----eval=FALSE---------------------------------------------------------------
# data(heart_data)
# data <- heart_data

## ----eval=FALSE---------------------------------------------------------------
# head(data)

## ----eval=FALSE---------------------------------------------------------------
# piechart(chest_pain_type)

## ----eval=FALSE---------------------------------------------------------------
# piechart(chest_pain_type, sex)

## ----eval=FALSE---------------------------------------------------------------
# descriptives(age, resting_bp)

